function biologia(){
    window.open('https://www.ifpb.edu.br/itaporanga/noticias/2018/09/robotica-do-campus-se-classifica-para-etapa-estadual-da-olimpiada-brasileira-de-robotica')
}
function informatica(){
    window.open('http://www.ifpb.edu.br/campinagrande/noticias/2018/11/estudantes-do-campus-campina-ganham-ouro-prata-e-bronze-em-olimpiada')
}
function robotica(){
    window.open('https://www.ifpb.edu.br/itaporanga/noticias/2018/09/robotica-do-campus-se-classifica-para-etapa-estadual-da-olimpiada-brasileira-de-robotica')
}
function fisica(){
    window.open('https://estudante.ifpb.edu.br/noticias/campus-campina-premia-vencedores-da-olimpiada-campinense-de-fisica')
}
function historia(){
    window.open('https://www.ifpb.edu.br/campinagrande/noticias/2018/08/ifpb-lidera-numero-de-finalistas-em-olimpiada-nacional-de-historia')
}
function quimica(){
    window.open('https://www.ifpb.edu.br/joaopessoa/noticias/2017/11/estudantes-do-campus-joao-pessoa-conquistam-medalhas-na-olimpiada-paraibana-de-quimica')
}
function matematica(){
    window.open('http://www.ifpb.edu.br/campinagrande/noticias/2016/12/alunos-do-campus-campina-grande-sao-premiados-na-olimpiada-pessoense-de-matematica')
}
function medicinais(){
    window.open('http://www.ifpb.edu.br/sousa/noticias/2019/02/projeto-de-extensao-instala-canteiros-medicinais-em-sousa')
}
function concurso(){
    window.open('https://www.ifpb.edu.br/joaopessoa/noticias/2018/02/aprovados-em-concurso-do-estado-alunos-do-ifpb-relatam-experiencia-na-graduacao')
}
function teatro(){
    window.open('https://www.ifpb.edu.br/campinagrande/noticias/2018/12/espetaculo-teatral-de-alunos-do-ifpb-campina-e-apresentado-em-escola-municipal')
}
function cordel(){
    window.open('https://www.ifpb.edu.br/campinagrande/noticias/2017/11/literatura-de-cordel-para-despertar-o-prazer-pela-leitura')
}
function racismo(){
    window.open('https://www.ifpb.edu.br/campinagrande/noticias/2017/12/i-semana-de-combate-a-intolerancia-e-ao-racismo')
}
function agricultura(){
    window.open('http://www.ifpb.edu.br/esperanca/noticias/2017/11/acoes-de-extensao-do-campus-esperanca')
}
function expotec(){
    window.open('http://www.ifpb.edu.br/noticias/2018/11/ifpb-participa-da-expotec-2018')
}
function lampeju(){
    window.open('https://lampejuifpb.wordpress.com/about/')
}
function inclusao(){
    window.open('http://www.ifpb.edu.br/campinagrande/noticias/2016/11/semana-de-inclusao-de-campina-promoveu-conscientizacao-atraves-das-artes-1')
}
function olimpiadahistoria2017() {
    window.open('https://estudante.ifpb.edu.br/noticias/equipe-do-campus-campina-ganha-bronze-em-olimpiada-de-historia ')
}
function olimpiadamatematica20161() {
    window.open(' http://www.ifpb.edu.br/campinagrande/noticias/2016/12/alunos-do-campus-campina-grande-sao-premiados-na-olimpiada-pessoense-de-matematica ')
}
function geografia() {
    window.open('http://www.ifpb.edu.br/noticias/2018/09/equipes-do-ifpb-sao-medalha-de-ouro-na-olimpiada-brasileira-de-geografia')
}
function tresSIMPIF() {
    window.open(' http://www.ifpb.edu.br/noticias/2019/05/prpipg-anuncia-realizacao-do-3o-simpif ')
}
function seisartigos() {
    window.open('http://www.ifpb.edu.br/campinagrande/noticias/2017/02/estudantes-de-campina-aprovam-seis-artigos-em-congresso-nacional')
}
function campanhalivros() {
    window.open('https://www.ifpb.edu.br/campinagrande/noticias/2018/05/biblioteca-lanca-campanha-de-doacao-de-livros')
}
function semanaCienciaTecnologia2018() {
    window.open('http://www.ifpb.edu.br/campinagrande/noticias/2018/11/semana-de-ciencia-e-tecnologia-do-campus-campina')
}
function arteemcena(){
    window.open('http://www.ifpb.edu.br/guarabira/noticias/2017/10/campus-guarabira-realiza-projeto-de-extensao-arte-em-cena')
}
function musicaeesucacao(){
    window.open('http://www.ifpb.edu.br/joaopessoa/noticias/2016/09/projeto-musica-e-educacao-chega-a-mais-duas-escolas-da-capital')
}
function novembromusical(){
    window.open('http://www.ifpb.edu.br/cajazeiras/noticias/2017/11/projeto-novembro-musical-ano-ii')
}
function librasquim(){
    window.open('http://www.ifpb.edu.br/joaopessoa/noticias/2019/01/glossario-de-quimica-em-libras-auxilia-no-processo-de-ensino-aprendizagem-de-alunos-do-campus-jp')
}
function intercambio(){
    window.open('http://www.ifpb.edu.br/joaopessoa/noticias/2018/11/participantes-de-intercambio-promovem-i-workshop-projeto-201cenglish-through-toronto201d')
}
function olimpiadamatematica2016(){
    window.open('http://www.ifpb.edu.br/cajazeiras/noticias/2016/08/premiacao-da-olimpiada-cajazeirense-de-matematica')
}
function biologia1(){
    window.open('http://www.ifpb.edu.br/princesaisabel/noticias/2016/08/reuniao-de-apresentacao-do-programa-biologia-em-contexto')
}
function uraca(){
    window.open('https://www.ifpb.edu.br/campinagrande/noticias/2018/03/extensionistas-de-campina-se-reunem-para-mapeamento-de-acoes')
}

