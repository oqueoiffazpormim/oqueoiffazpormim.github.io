function intel(){
    window.open('http://g1.globo.com/pb/paraiba/noticia/2014/03/aluna-do-ifpb-conquista-premio-internacional-em-feira-de-tecnologia.html');
}

function ioi(){
    window.open('http://editor.ifpb.edu.br/campi/campina-grande/noticias/estudante-do-ifpb-disputara-vaga-em-seletiva-internacional-de-informatica-2');
}

function maratona(){
    window.open('http://editor.ifpb.edu.br/campi/campina-grande/noticias/aplicativo-criado-por-estudantes-de-campina-e-selecionado-em-concurso-nacional-1');
}

function engenharia(){
    window.open('http://www.ifpb.edu.br/cajazeiras/noticias/2017/05/aluno-de-cajazeiras-representara-o-brasil-em-congresso-internacional-de-engenharia');
}

function polonia(){
    window.open('https://g1.globo.com/pb/paraiba/noticia/paraibano-faz-vaquinha-para-estudar-na-polonia-e-ser-primeiro-universitario-da-familia.ghtml');
}

function brics(){
    window.open('http://www.ifpb.edu.br/noticias/2018/06/aluna-do-campus-cabedelo-disputa-premio-internacional-de-jovens-cientistas');
}